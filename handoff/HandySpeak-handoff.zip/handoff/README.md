# HandySpeak — Handoff Archive

HandySpeak is an AAC (augmentative & alternative communication) tablet app for
non-speaking children: it composes messages into a spoken message bar via a
letter **Keyboard**, a pictogram **Symbols** board, and a **Math** board, with
mood-driven text-to-speech and three full locales — **English, Czech, and
Ukrainian** — of which the parent picks a two-language pair for the kid-facing
toggle.

## What's in this archive

- **`ADDENDUM-01 Big letters + Optional phrases.md`** — two approved parent
  settings (uppercase-only "Big letters"; optional "My phrases" strip).
- **`ADDENDUM-02 Math board + inline numbers.md`** — the Math input mode,
  Czech inline-number row swap, and the two-workspace (sentence vs. problem)
  message buffer.
- **`ADDENDUM-03 Ukrainian layout + language pair.md`** — the Ukrainian locale
  (ЙЦУКЕН keyboard, full UI/vocabulary translation, uk-UA TTS) and the
  parent-chosen base/second language pair with per-language voice-pack
  warnings.
- **`HandySpeak (working prototype).html`** — the self-contained POC. Open in
  a browser to interact with every feature the addenda describe. It renders on
  a design canvas (pan/zoom; many artboards including the Math and Czech
  keyboard states).
- **`POC-source/`** — the un-bundled reference source the addenda cite by
  filename:
  - `tablet.jsx` — the tablet app (modes, keyboard, math board, message bar,
    settings, TTS, math helpers `mathSpeak`/`mathAppendDigit`/`mathAppendOp`).
  - `word-blocks.jsx` — the editable word-tile message bar.
  - `i18n.jsx` — the EN/CS/UK string tables + translation helpers.
  - `styles.css` — the design system + component CSS (selectors referenced in
    the addenda live here).
  - `app.jsx` — the design-canvas root wiring the artboards.

## How to use these files

The HTML/JSX here are **design references** — prototypes showing intended look
and behavior, not production code to ship. The task is to **recreate these
designs in the target codebase's existing environment** (React, native, etc.)
using its established patterns, or to pick the best-fit framework if none
exists yet. The prototypes are **high-fidelity**: colors, typography, spacing,
copy, and interactions are final.

Read the addendum for the feature you're implementing; it gives the rationale,
exact behavior, POC reference selectors/functions, i18n strings, acceptance
criteria, and an explicit **Deferred** list of things NOT to build yet. Use the
working prototype to feel the interaction and `POC-source/` to see precisely
how it was done.
