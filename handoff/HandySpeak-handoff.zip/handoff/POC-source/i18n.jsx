/* HandySpeak — i18n layer
   POC scope: English (default) + Czech, kid-switchable.
   Design notes:
     • The emoji on a tile is language-independent; only the *word*
       under it changes. So translation is a parallel label/speech map
       layered over the same symbol grid — the board never rebuilds.
     • Every kid-facing surface resolves its label & spoken word through
       here, so one toggle flips both the UI and what the speech engine
       says.
*/

const LANGS = [
  { id: 'en', short: 'EN', name: 'English', bcp47: 'en-US', voicePrefix: 'en' },
  { id: 'cs', short: 'CZ', name: 'Čeština', bcp47: 'cs-CZ', voicePrefix: 'cs' },
  { id: 'uk', short: 'UK', name: 'Українська', bcp47: 'uk-UA', voicePrefix: 'uk' },
];

/* The kid-facing top-bar toggle shows exactly TWO languages: a base and a
   second one, chosen by the parent in Settings. Toggling is symmetric — it
   flips UI strings, keyboard layout, symbol words, phrases and TTS together.
   Base only means "first (left) in the toggle" and the default on launch. */

/* ---- UI chrome strings ---- */
const UI = {
  en: {
    keyboard: 'Keyboard',
    symbols: 'Symbols',
    math: 'Math',
    mathBack: 'ABC',
    backspace: 'Delete',
    snap: 'Snap & Say',
    settings: 'Settings',
    voiceLabel: 'Voice',
    myPhrases: 'My Phrases',
    speak: 'Speak',
    speaking: 'Speaking…',
    clear: 'Clear',
    voiceSuffix: 'voice',
    placeholder: 'Tap keys or symbols to compose…',
    justSnapped: 'Just snapped',
    space: 'space',
    closeLabel: 'Close',
    captureLabel: 'Capture',
    // snap & say
    snapPoint: 'Point at something — we’ll find the word',
    snapLooking: 'Looking…',
    snapISeeA: 'I see a',
    snapSure: 'sure',
    snapNotQuite: 'Not quite?',
    snapTryAgain: 'Try again',
    snapHear: 'Hear it',
    snapAdd: 'Add',
    snapDemo: 'Demo aim',
    // settings
    setPinned: 'Parent · Pinned Phrases',
    setUsed: 'used',
    setPin: 'Pin',
    setUnpin: 'Unpin',
    setAddPhrase: 'Add a phrase the child can quickly speak…',
    setAdd: 'Add',
    setEditing: 'Editing the message',
    setEditingNote: 'How a child can fix the sentence by changing word tiles. Tapping a tile is always available; the others are gestures layered on top.',
    setTapXName: 'Tap a word to remove it',
    setTapXDesc: 'Tap a tile to reveal a ✕. The safe, switch-friendly default.',
    setTapMoveName: 'Tap a word to move it',
    setTapMoveDesc: 'Reveal ◀ ▶ arrows to shift a word left or right.',
    setSwipeName: 'Swipe up to remove',
    setSwipeDesc: 'Flick a tile upward to throw the word away. Always undoable.',
    setDragName: 'Press & hold to reorder',
    setDragDesc: 'Hold a tile to lift it, then drag to a new spot. Higher motor demand.',
    setAccess: 'Accessibility',
    setScanName: 'Switch Scanning',
    setScanDesc: 'Auto-advance highlight; press any key or external switch to select.',
    setHapticName: 'Haptic feedback',
    setHapticDesc: 'Vibrate on key/card press (where supported).',
    setDarkName: 'Dark mode',
    setDarkDesc: 'Lower-contrast surfaces for low-light use.',
    setLanguage: 'Language',
    setLanguageDesc: 'Pick the two languages shown in the top bar. Tapping one switches the whole board and the speaking voice.',
    setBaseLang: 'Base language',
    setBaseLangDesc: 'Shown first in the top bar; the board starts here.',
    setSecondLang: 'Second language',
    setSecondLangDesc: 'The other language the child can flip to.',
    setVoice: 'Speaking voice',
    setMoodName: 'Mood voices',
    setMoodDesc: 'Let the child pick a mood that changes the voice’s pitch and speed. Off uses one steady voice.',
    voiceMissing: 'No voice for this language on the tablet yet — add one in your device’s speech settings for the best pronunciation.',
    voiceMissingNamed: 'No {lang} voice on this tablet yet — add one in your device’s speech settings for the best pronunciation.',
    setUpperName: 'Big letters',
    setUpperDesc: 'Show every letter as a capital and lock the shift key. Helps kids who don’t read lowercase yet — speech is unchanged.',
    setShowPhrasesName: 'Show phrase shortcuts',
    setShowPhrasesDesc: 'The quick-phrase strip above the keyboard. Turn off for kids who don’t read yet — keys and symbols grow bigger.',
    setPhrasesHiddenNote: 'Hidden on the board — phrases stay saved here and come back when you switch this on.',
  },
  cs: {
    keyboard: 'Klávesnice',
    symbols: 'Symboly',
    math: 'Počítání',
    mathBack: 'ABC',
    backspace: 'Smazat',
    snap: 'Vyfoť a řekni',
    settings: 'Nastavení',
    voiceLabel: 'Hlas',
    myPhrases: 'Moje fráze',
    speak: 'Mluvit',
    speaking: 'Mluvím…',
    clear: 'Smazat',
    voiceSuffix: 'hlas',
    placeholder: 'Ťukej na klávesy nebo symboly…',
    justSnapped: 'Právě vyfoceno',
    space: 'mezera',
    closeLabel: 'Zavřít',
    captureLabel: 'Vyfotit',
    // snap & say
    snapPoint: 'Namiř na něco — najdeme slovo',
    snapLooking: 'Hledám…',
    snapISeeA: 'Vidím',
    snapSure: 'jistota',
    snapNotQuite: 'Není to ono?',
    snapTryAgain: 'Zkusit znovu',
    snapHear: 'Přehrát',
    snapAdd: 'Přidat',
    snapDemo: 'Ukázka',
    // settings
    setPinned: 'Rodič · Připnuté fráze',
    setUsed: 'použito',
    setPin: 'Připnout',
    setUnpin: 'Odepnout',
    setAddPhrase: 'Přidej frázi, kterou dítě rychle řekne…',
    setAdd: 'Přidat',
    setEditing: 'Úpravy zprávy',
    setEditingNote: 'Jak může dítě opravit větu změnou dlaždic se slovy. Ťuknutí na dlaždici jde vždy; ostatní jsou gesta navíc.',
    setTapXName: 'Ťuknutím slovo odebrat',
    setTapXDesc: 'Ťukni na dlaždici a objeví se ✕. Bezpečné, vhodné i pro spínače.',
    setTapMoveName: 'Ťuknutím slovo přesunout',
    setTapMoveDesc: 'Zobrazí šipky ◀ ▶ pro posun slova doleva nebo doprava.',
    setSwipeName: 'Smazat švihnutím nahoru',
    setSwipeDesc: 'Švihni dlaždicí nahoru a slovo zahodíš. Vždy lze vrátit.',
    setDragName: 'Podržením přeskupit',
    setDragDesc: 'Podrž dlaždici, zvedni ji a přetáhni jinam. Náročnější na pohyb.',
    setAccess: 'Přístupnost',
    setScanName: 'Skenování spínačem',
    setScanDesc: 'Zvýraznění se samo posouvá; vyber stiskem klávesy nebo spínače.',
    setHapticName: 'Vibrace',
    setHapticDesc: 'Zavibruje při stisku klávesy/dlaždice (kde to jde).',
    setDarkName: 'Tmavý režim',
    setDarkDesc: 'Méně kontrastní plochy pro použití v šeru.',
    setLanguage: 'Jazyk',
    setLanguageDesc: 'Vyber dva jazyky zobrazené v horní liště. Ťuknutí přepne celou tabulku i mluvící hlas.',
    setBaseLang: 'Základní jazyk',
    setBaseLangDesc: 'V horní liště je první; tabulka jím začíná.',
    setSecondLang: 'Druhý jazyk',
    setSecondLangDesc: 'Druhý jazyk, na který dítě může přepnout.',
    setVoice: 'Mluvený hlas',
    setMoodName: 'Nálady hlasu',
    setMoodDesc: 'Dítě si může vybrat náladu, která mění výšku a rychlost hlasu. Vypnuto = jeden stálý hlas.',
    voiceMissing: 'V tabletu zatím není hlas pro tento jazyk — přidej ho v nastavení řeči zařízení pro nejlepší výslovnost.',
    voiceMissingNamed: 'V tabletu zatím není hlas pro jazyk {lang} — přidej ho v nastavení řeči zařízení pro nejlepší výslovnost.',
    setUpperName: 'Velká písmena',
    setUpperDesc: 'Všechna písmena se zobrazí jako velká a klávesa shift se uzamkne. Pomáhá dětem, které ještě nečtou malá písmena — řeč se nemění.',
    setShowPhrasesName: 'Zobrazit lištu frází',
    setShowPhrasesDesc: 'Lišta rychlých frází nad klávesnicí. Vypni pro děti, které ještě nečtou — klávesy a symboly se zvětší.',
    setPhrasesHiddenNote: 'Na tabulce skryto — fráze tu zůstávají uložené a vrátí se po zapnutí.',
  },
  uk: {
    keyboard: 'Клавіатура',
    symbols: 'Символи',
    math: 'Лічба',
    mathBack: 'АБВ',
    backspace: 'Стерти',
    snap: 'Сфоткай і скажи',
    settings: 'Налаштування',
    voiceLabel: 'Голос',
    myPhrases: 'Мої фрази',
    speak: 'Говорити',
    speaking: 'Говорю…',
    clear: 'Стерти',
    voiceSuffix: 'голос',
    placeholder: 'Торкай клавіші або символи…',
    justSnapped: 'Щойно сфоткано',
    space: 'пробіл',
    closeLabel: 'Закрити',
    captureLabel: 'Сфоткати',
    // snap & say
    snapPoint: 'Наведи на щось — ми знайдемо слово',
    snapLooking: 'Шукаю…',
    snapISeeA: 'Бачу',
    snapSure: 'впевненість',
    snapNotQuite: 'Не те?',
    snapTryAgain: 'Спробувати ще',
    snapHear: 'Послухати',
    snapAdd: 'Додати',
    snapDemo: 'Демо',
    // settings
    setPinned: 'Батьки · Закріплені фрази',
    setUsed: 'вжито',
    setPin: 'Закріпити',
    setUnpin: 'Відкріпити',
    setAddPhrase: 'Додай фразу, яку дитина швидко скаже…',
    setAdd: 'Додати',
    setEditing: 'Редагування повідомлення',
    setEditingNote: 'Як дитина може виправити речення, змінюючи плитки зі словами. Торкнутися плитки можна завжди; інше — додаткові жести.',
    setTapXName: 'Торкнися слова, щоб видалити',
    setTapXDesc: 'Торкнися плитки — з’явиться ✕. Безпечно, підходить і для перемикачів.',
    setTapMoveName: 'Торкнися слова, щоб пересунути',
    setTapMoveDesc: 'З’являються стрілки ◀ ▶ для зсуву слова ліворуч чи праворуч.',
    setSwipeName: 'Змахни вгору, щоб видалити',
    setSwipeDesc: 'Змахни плиткою вгору — слово викинеться. Завжди можна повернути.',
    setDragName: 'Натисни й утримуй, щоб переставити',
    setDragDesc: 'Утримуй плитку, підніми й перетягни на нове місце. Складніше для моторики.',
    setAccess: 'Доступність',
    setScanName: 'Сканування перемикачем',
    setScanDesc: 'Підсвітка рухається сама; вибирай натисканням клавіші чи перемикача.',
    setHapticName: 'Вібрація',
    setHapticDesc: 'Вібрує при натисканні клавіші/плитки (де підтримується).',
    setDarkName: 'Темний режим',
    setDarkDesc: 'Менш контрастні поверхні для темного приміщення.',
    setLanguage: 'Мова',
    setLanguageDesc: 'Обери дві мови для верхньої панелі. Дотик перемикає всю дошку й голос.',
    setBaseLang: 'Основна мова',
    setBaseLangDesc: 'Перша у верхній панелі; дошка починає з неї.',
    setSecondLang: 'Друга мова',
    setSecondLangDesc: 'Інша мова, на яку дитина може перемкнутися.',
    setVoice: 'Голос мовлення',
    setMoodName: 'Голоси настрою',
    setMoodDesc: 'Дитина може обрати настрій, що змінює висоту й швидкість голосу. Вимкнено = один рівний голос.',
    voiceMissing: 'На планшеті ще немає голосу для цієї мови — додай його в налаштуваннях мовлення пристрою.',
    voiceMissingNamed: 'На планшеті ще немає голосу для мови «{lang}» — додай його в налаштуваннях мовлення пристрою для найкращої вимови.',
    setUpperName: 'Великі літери',
    setUpperDesc: 'Усі літери показуються великими, клавіша shift блокується. Допомагає дітям, які ще не читають малі літери — мовлення не змінюється.',
    setShowPhrasesName: 'Показувати панель фраз',
    setShowPhrasesDesc: 'Смужка швидких фраз над клавіатурою. Вимкни для дітей, які ще не читають — клавіші й символи стануть більшими.',
    setPhrasesHiddenNote: 'На дошці приховано — фрази зберігаються тут і повернуться після увімкнення.',
  },
};

/* ---- Vocabulary: English word (id) -> Czech ---- */
const WORDS_CS = {
  // feelings
  happy: 'šťastný', sad: 'smutný', tired: 'unavený', scared: 'vyděšený',
  excited: 'nadšený', angry: 'naštvaný', love: 'láska', calm: 'klidný',
  silly: 'bláznivý', shy: 'stydlivý',
  // food
  apple: 'jablko', water: 'voda', milk: 'mléko', pizza: 'pizza',
  banana: 'banán', cookie: 'sušenka', sandwich: 'sendvič', pasta: 'těstoviny',
  cereal: 'cereálie', juice: 'džus',
  // school
  book: 'kniha', pencil: 'tužka', teacher: 'učitelka', art: 'výtvarka',
  math: 'matika', recess: 'přestávka', music: 'hudba', computer: 'počítač',
  science: 'věda', reading: 'čtení',
  // family
  mom: 'máma', dad: 'táta', sister: 'sestra', brother: 'bratr',
  grandma: 'babička', grandpa: 'děda', baby: 'miminko', dog: 'pes',
  cat: 'kočka', friend: 'kamarád',
  // activities
  play: 'hrát', draw: 'kreslit', run: 'běhat', jump: 'skákat',
  sleep: 'spát', sing: 'zpívat', dance: 'tancovat', swim: 'plavat',
  read: 'číst', build: 'stavět',
  // places
  home: 'domov', school: 'škola', park: 'park', store: 'obchod',
  bathroom: 'záchod', kitchen: 'kuchyně', outside: 'venku', car: 'auto',
  beach: 'pláž', doctor: 'doktor',
  // numbers
  one: 'jedna', two: 'dvě', three: 'tři', four: 'čtyři', five: 'pět',
  more: 'víc', less: 'míň', all: 'všechno', none: 'nic', some: 'trochu',
  // greetings
  hello: 'ahoj', goodbye: 'pa pa', please: 'prosím', 'thank you': 'děkuji',
  sorry: 'promiň', yes: 'ano', no: 'ne', okay: 'dobře',
  'good morning': 'dobré ráno', 'good night': 'dobrou noc',
  // snap targets + alts
  ball: 'míč', cup: 'hrnek',
  bread: 'chléb', wrap: 'tortilla', lunch: 'oběd',
  puppy: 'štěně', pet: 'mazlíček',
  football: 'fotbal', soccer: 'fotbal',
  novel: 'román', story: 'příběh',
  fruit: 'ovoce', snack: 'svačina',
  drink: 'pití', glass: 'sklenice',
};

const CATS_CS = {
  feelings: 'Pocity', food: 'Jídlo', school: 'Škola', family: 'Rodina',
  activities: 'Činnosti', places: 'Místa', numbers: 'Čísla', greetings: 'Ahoj',
};

const MOODS_CS = {
  happy: 'Šťastný', excited: 'Nadšený', calm: 'Klidný',
  curious: 'Zvědavý', sad: 'Smutný', angry: 'Naštvaný',
};

const PHRASES_CS = {
  'I need help': 'Potřebuju pomoc',
  'Bathroom please': 'Záchod prosím',
  "I'm hungry": 'Mám hlad',
  "I don't understand": 'Nerozumím',
  'Thank you': 'Děkuji',
  'Yes please': 'Ano prosím',
  'Can I play?': 'Můžu si hrát?',
  'All done': 'Hotovo',
};

/* ---- Vocabulary: English word (id) -> Ukrainian ---- */
const WORDS_UK = {
  // feelings
  happy: 'щасливий', sad: 'сумний', tired: 'втомлений', scared: 'наляканий',
  excited: 'радісний', angry: 'сердитий', love: 'любов', calm: 'спокійний',
  silly: 'кумедний', shy: 'сором’язливий',
  // food
  apple: 'яблуко', water: 'вода', milk: 'молоко', pizza: 'піца',
  banana: 'банан', cookie: 'печиво', sandwich: 'бутерброд', pasta: 'макарони',
  cereal: 'пластівці', juice: 'сік',
  // school
  book: 'книжка', pencil: 'олівець', teacher: 'вчителька', art: 'малювання',
  math: 'математика', recess: 'перерва', music: 'музика', computer: 'комп’ютер',
  science: 'наука', reading: 'читання',
  // family
  mom: 'мама', dad: 'тато', sister: 'сестра', brother: 'брат',
  grandma: 'бабуся', grandpa: 'дідусь', baby: 'малюк', dog: 'пес',
  cat: 'кіт', friend: 'друг',
  // activities
  play: 'гратися', draw: 'малювати', run: 'бігати', jump: 'стрибати',
  sleep: 'спати', sing: 'співати', dance: 'танцювати', swim: 'плавати',
  read: 'читати', build: 'будувати',
  // places
  home: 'дім', school: 'школа', park: 'парк', store: 'магазин',
  bathroom: 'туалет', kitchen: 'кухня', outside: 'надворі', car: 'авто',
  beach: 'пляж', doctor: 'лікар',
  // numbers
  one: 'один', two: 'два', three: 'три', four: 'чотири', five: 'п’ять',
  more: 'більше', less: 'менше', all: 'усе', none: 'нічого', some: 'трохи',
  // greetings
  hello: 'привіт', goodbye: 'бувай', please: 'будь ласка', 'thank you': 'дякую',
  sorry: 'вибач', yes: 'так', no: 'ні', okay: 'гаразд',
  'good morning': 'доброго ранку', 'good night': 'на добраніч',
  // snap targets + alts
  ball: 'м’яч', cup: 'чашка',
  bread: 'хліб', wrap: 'лаваш', lunch: 'обід',
  puppy: 'цуценя', pet: 'улюбленець',
  football: 'футбол', soccer: 'футбол',
  novel: 'роман', story: 'історія',
  fruit: 'фрукт', snack: 'перекус',
  drink: 'напій', glass: 'склянка',
};

const CATS_UK = {
  feelings: 'Почуття', food: 'Їжа', school: 'Школа', family: 'Родина',
  activities: 'Заняття', places: 'Місця', numbers: 'Числа', greetings: 'Привіт',
};

const MOODS_UK = {
  happy: 'Щасливий', excited: 'Радісний', calm: 'Спокійний',
  curious: 'Допитливий', sad: 'Сумний', angry: 'Сердитий',
};

const PHRASES_UK = {
  'I need help': 'Мені потрібна допомога',
  'Bathroom please': 'В туалет, будь ласка',
  "I'm hungry": 'Я голодний',
  "I don't understand": 'Я не розумію',
  'Thank you': 'Дякую',
  'Yes please': 'Так, будь ласка',
  'Can I play?': 'Можна мені погратися?',
  'All done': 'Готово',
};

/* ---- tiny Czech prediction table (keyboard is secondary in AAC) ---- */
const PREDICT_CS = {
  '':       ['Já',    'Chci',   'Můžu'],
  'ch':     ['chci',  'chleba', 'chvíli'],
  'chc':    ['chci',  'chceš',  'chceme'],
  'ma':     ['mám',   'máma',   'malý'],
  'mam':    ['mám',   'máma'],
  'po':     ['pomoc', 'potom',  'počkej'],
  'pom':    ['pomoc', 'pomoz',  'pomalu'],
  'ano':    ['ano'],
  'ne':     ['ne',    'nechci', 'nevím'],
  'pr':     ['prosím','proč',   'pryč'],
  'pro':    ['prosím','proč',   'protože'],
  'de':     ['děkuji','děti',   'den'],
  'dek':    ['děkuji'],
  'hl':     ['hlad',  'hledat'],
};

/* Ukrainian prediction: out of scope for now — only sentence starters so the
   strip isn't empty; typed words fall through unchanged. */
const PREDICT_UK = {
  '': ['Я', 'Хочу', 'Мені'],
};

/* ---- per-language lookup maps ---- */
const WORDS_BY_LANG   = { cs: WORDS_CS,   uk: WORDS_UK };
const CATS_BY_LANG    = { cs: CATS_CS,    uk: CATS_UK };
const MOODS_BY_LANG   = { cs: MOODS_CS,   uk: MOODS_UK };
const PHRASES_BY_LANG = { cs: PHRASES_CS, uk: PHRASES_UK };

/* ---- resolvers ---- */
function t(lang, key) {
  return (UI[lang] || UI.en)[key] ?? UI.en[key] ?? key;
}
function trWord(lang, w) {
  const map = WORDS_BY_LANG[lang];
  if (!map || !w) return w;
  return map[w.toLowerCase()] || w;
}
function trCat(lang, id, fallback) {
  const map = CATS_BY_LANG[lang];
  return map ? (map[id] || fallback) : fallback;
}
function trMood(lang, id, fallback) {
  const map = MOODS_BY_LANG[lang];
  return map ? (map[id] || fallback) : fallback;
}
function trPhrase(lang, text) {
  const map = PHRASES_BY_LANG[lang];
  return map ? (map[text] || text) : text;
}
/* Slavic word counts are number-sensitive:
   cs — 1 slovo · 2–4 slova · 5+ slov
   uk — 1 слово · 2–4 слова · 5+ слів (з винятком 11–14) */
function wordCount(lang, n) {
  if (lang === 'cs') {
    if (n === 1) return '1 slovo';
    if (n >= 2 && n <= 4) return n + ' slova';
    return n + ' slov';
  }
  if (lang === 'uk') {
    const m10 = n % 10, m100 = n % 100;
    if (m10 === 1 && m100 !== 11) return n + ' слово';
    if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return n + ' слова';
    return n + ' слів';
  }
  return n + (n === 1 ? ' word' : ' words');
}

Object.assign(window, {
  LANGS, t, trWord, trCat, trMood, trPhrase, wordCount, PREDICT_CS, PREDICT_UK,
});
