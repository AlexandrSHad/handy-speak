/* HandySpeak — Design Canvas root */

function Root() {
  const { DesignCanvas, DCSection, DCArtboard, HandySpeakApp, DSColors, DSType, DSSpacing, DSMoodMatrix, DSPrinciples } = window;
  return (
    <DesignCanvas>
      <DCSection id="multilingual" title="Multilingual · EN ⇄ CZ" subtitle="Kid-switchable language in the top bar — one tap flips the whole board, the prediction bar, and the speaking voice. POC: English + Czech.">
        <DCArtboard id="ml-en" label="Symbols · English" width={1280} height={920}>
          <HandySpeakApp initialMode="symbols" initialLang="en" initialMessage="I want apple" initialMood="happy" initialCategory="food"/>
        </DCArtboard>

        <DCArtboard id="ml-cs" label="Symbols · Čeština" width={1280} height={920}>
          <HandySpeakApp initialMode="symbols" initialLang="cs" initialMessage="máma kniha" initialMood="happy" initialCategory="family"/>
        </DCArtboard>

        <DCArtboard id="ml-cs-keyboard" label="Keyboard + prediction · Čeština" width={1280} height={920}>
          <HandySpeakApp initialMode="keyboard" initialLang="cs" initialMessage="pom" initialMood="calm"/>
        </DCArtboard>

        <DCArtboard id="ml-cs-settings" label="Settings · Jazyk + voice note" width={1280} height={920}>
          <HandySpeakApp initialMode="symbols" initialLang="cs" initialMessage="" initialMood="calm" showSettings={true}/>
        </DCArtboard>

        <DCArtboard id="ml-cs-snap" label="Snap & Say · Čeština" width={1280} height={920}>
          <HandySpeakApp initialMode="symbols" initialLang="cs" initialMessage="" initialMood="curious" showSnap={true} snapPhase="result" snapTarget="apple"/>
        </DCArtboard>
      </DCSection>

      <DCSection id="cz-numbers" title="Inline numbers · Czech keyboard" subtitle="Czech has no room for a permanent digit row — its top row is 15 diacritics. So the bottom 123 key swaps that row into digits in place (no motion, nothing covered). The key reads 123 when letters show, ABC when digits show, and stays open until pressed again — no overlay, no Done. Tap 123 to try it.">
        <DCArtboard id="cz-num-swap" label="Diacritics row becomes digits in place" width={1280} height={920}>
          <HandySpeakApp initialLang="cs" initialMessage="potřebuji" initialMood="happy"/>
        </DCArtboard>
      </DCSection>

      <DCSection id="ukrainian" title="Ukrainian · ЙЦУКЕН + language pair" subtitle="Third locale. All 33 letters plus the orthographic apostrophe are first-class keys — no AltGr (AAC rule): 12/12/10 with ґ closing row 2 and ʼ closing row 3, digits permanent on top like English. The kid toggle still shows exactly two languages; the parent picks the base + second pair in Settings.">
        <DCArtboard id="uk-keyboard" label="Keyboard · Українська (EN + UK pair)" width={1280} height={920}>
          <HandySpeakApp initialMode="keyboard" initialLang="uk" initialBaseLang="en" initialSecondLang="uk" initialMessage="я хочу" initialMood="happy"/>
        </DCArtboard>

        <DCArtboard id="uk-symbols" label="Symbols · Українська (CZ + UK pair)" width={1280} height={920}>
          <HandySpeakApp initialMode="symbols" initialLang="uk" initialBaseLang="cs" initialSecondLang="uk" initialMessage="мама" initialMood="calm" initialCategory="family"/>
        </DCArtboard>

        <DCArtboard id="uk-lang-pair" label="Settings · Base + second language" width={1280} height={920}>
          <HandySpeakApp initialMode="keyboard" initialLang="uk" initialBaseLang="uk" initialSecondLang="cs" initialMessage="" initialMood="calm" showSettings={true}/>
        </DCArtboard>

        <DCArtboard id="uk-big-letters" label="Big letters · Українська" width={1280} height={920}>
          <HandySpeakApp initialMode="keyboard" initialUpperOnly={true} initialLang="uk" initialBaseLang="en" initialSecondLang="uk" initialMessage="я голодний" initialMood="calm"/>
        </DCArtboard>
      </DCSection>

      <DCSection id="math" title="Math · arithmetic &amp; comparison" subtitle="A third board — the 123 pill (and the keyboard’s ?123 key) — composes simple problems into the same message bar. No calculation: pressing Speak voices it (“three plus four equals seven”) in the active language and mood. Digits group into one tile; signs stand alone and are editable like any word.">
        <DCArtboard id="math-add" label="Addition · 3 + 4 = 7" width={1280} height={920}>
          <HandySpeakApp initialMode="math" initialMessage="3 + 4 = 7" initialMood="happy"/>
        </DCArtboard>

        <DCArtboard id="math-compare" label="Comparison · 8 > 5" width={1280} height={920}>
          <HandySpeakApp initialMode="math" initialMessage="8 > 5" initialMood="curious"/>
        </DCArtboard>

        <DCArtboard id="math-empty" label="Empty · ready to compose" width={1280} height={920}>
          <HandySpeakApp initialMode="math" initialMessage="" initialMood="calm"/>
        </DCArtboard>

        <DCArtboard id="math-cs" label="Math · Čeština · 12 ÷ 4 = 3" width={1280} height={920}>
          <HandySpeakApp initialMode="math" initialLang="cs" initialMessage="12 ÷ 4 = 3" initialMood="calm"/>
        </DCArtboard>

        <DCArtboard id="math-dark" label="Math · Dark · 9 − 4 = 5" width={1280} height={920}>
          <HandySpeakApp initialMode="math" initialDark={true} initialMessage="9 − 4 = 5" initialMood="calm"/>
        </DCArtboard>
      </DCSection>

      <DCSection id="snap-say" title="Snap &amp; Say" subtitle="Camera-driven word capture · bridges the gap when the right icon isn't in the library">
        <DCArtboard id="snap-aim" label="Aim · viewfinder" width={1280} height={920}>
          <HandySpeakApp initialMode="symbols" initialMessage="I want a" initialMood="curious" showSnap={true} snapPhase="aim" snapTarget="sandwich"/>
        </DCArtboard>

        <DCArtboard id="snap-analyzing" label="Analyzing" width={1280} height={920}>
          <HandySpeakApp initialMode="symbols" initialMessage="I want a" initialMood="curious" showSnap={true} snapPhase="analyzing" snapTarget="dog"/>
        </DCArtboard>

        <DCArtboard id="snap-result" label="Result · sandwich detected" width={1280} height={920}>
          <HandySpeakApp initialMode="symbols" initialMessage="I want a" initialMood="curious" showSnap={true} snapPhase="result" snapTarget="sandwich"/>
        </DCArtboard>

        <DCArtboard id="snap-added" label="After adding · recent strip" width={1280} height={920}>
          <HandySpeakApp
            initialMode="symbols"
            initialMessage="I want a sandwich"
            initialMood="happy"
            initialCategory="food"
            initialRecent={[
              { word: "sandwich", emoji: "🥪" },
              { word: "apple",    emoji: "🍎" },
              { word: "dog",      emoji: "🐕" },
            ]}
          />
        </DCArtboard>
      </DCSection>

      <DCSection id="tablet-primary" title="Tablet · Primary" subtitle="iPad landscape · 1280×920 · Two composition modes sharing one message bar">
        <DCArtboard id="keyboard-light" label="Keyboard mode · Light" width={1280} height={920}>
          <HandySpeakApp initialMode="keyboard" initialMessage="I want to play" initialMood="excited"/>
        </DCArtboard>

        <DCArtboard id="symbols-light" label="Symbol board · Light" width={1280} height={920}>
          <HandySpeakApp initialMode="symbols" initialMessage="I feel" initialMood="happy" initialCategory="feelings"/>
        </DCArtboard>

        <DCArtboard id="keyboard-dark" label="Keyboard mode · Dark" width={1280} height={920}>
          <HandySpeakApp initialMode="keyboard" initialDark={true} initialMessage="goodnight mom" initialMood="calm"/>
        </DCArtboard>

        <DCArtboard id="symbols-categories" label="Symbol board · Food" width={1280} height={920}>
          <HandySpeakApp initialMode="symbols" initialMessage="I'm hungry I want" initialMood="curious" initialCategory="food"/>
        </DCArtboard>
      </DCSection>

      <DCSection id="states" title="States &amp; Accessibility" subtitle="The same product under different access modes and conditions">
        <DCArtboard id="scanning" label="Switch scanning active" width={1280} height={920}>
          <HandySpeakApp initialMode="keyboard" initialScan={true} initialMessage="Yes I need" initialMood="calm"/>
        </DCArtboard>

        <DCArtboard id="settings-sheet" label="Parent · Settings sheet" width={1280} height={920}>
          <HandySpeakApp initialMode="keyboard" initialMessage="I need help" showSettings={true} initialMood="calm"/>
        </DCArtboard>

        <DCArtboard id="empty" label="Empty state · First launch" width={1280} height={920}>
          <HandySpeakApp initialMode="symbols" initialMessage="" initialMood="calm" initialCategory="greetings"/>
        </DCArtboard>

        <DCArtboard id="mood-off" label="Mood voices off · steady voice" width={1280} height={920}>
          <HandySpeakApp initialMode="keyboard" initialMoodEnabled={false} initialMessage="I need help" initialMood="calm"/>
        </DCArtboard>

        <DCArtboard id="big-letters" label="Big letters · shift locked" width={1280} height={920}>
          <HandySpeakApp initialMode="keyboard" initialUpperOnly={true} initialMessage="I want to play" initialMood="happy"/>
        </DCArtboard>

        <DCArtboard id="big-letters-cs" label="Big letters · Čeština" width={1280} height={920}>
          <HandySpeakApp initialMode="keyboard" initialUpperOnly={true} initialLang="cs" initialMessage="mám hlad" initialMood="calm"/>
        </DCArtboard>

        <DCArtboard id="no-phrases" label="Phrases hidden · bigger keys" width={1280} height={920}>
          <HandySpeakApp initialMode="keyboard" initialShowPhrases={false} initialMessage="" initialMood="calm"/>
        </DCArtboard>
      </DCSection>

      <DCSection id="word-blocks" title="Editable Word Blocks" subtitle="Every word is a tile you can fix · tap to reveal ✕, swipe up to toss, hold to reorder · all four affordances toggle in Settings">
        <DCArtboard id="blocks-tapx" label="Tap a word · ✕ revealed" width={1280} height={920}>
          <HandySpeakApp initialMode="symbols" initialMessage="I want to play outside" initialMood="excited" initialCategory="feelings" initialTapX={true} initialSelectedWord={3}/>
        </DCArtboard>

        <DCArtboard id="blocks-move" label="Tap a word · move arrows" width={1280} height={920}>
          <HandySpeakApp initialMode="symbols" initialMessage="I want to play outside" initialMood="curious" initialCategory="feelings" initialTapX={true} initialTapMove={true} initialSelectedWord={2}/>
        </DCArtboard>

        <DCArtboard id="blocks-settings" label="Parent · choose affordances" width={1280} height={920}>
          <HandySpeakApp initialMode="symbols" initialMessage="I want to play outside" initialMood="calm" showSettings={true}/>
        </DCArtboard>
      </DCSection>

      <DCSection id="design-system" title="Design System" subtitle="Tokens, type, spacing — the rules every screen follows">
        <DCArtboard id="principles" label="Principles" width={960} height={760}>
          <DSPrinciples />
        </DCArtboard>

        <DCArtboard id="mood-matrix" label="Mood → Voice mapping" width={960} height={760}>
          <DSMoodMatrix />
        </DCArtboard>

        <DCArtboard id="colors-light" label="Colors · Light" width={960} height={920}>
          <DSColors dark={false}/>
        </DCArtboard>

        <DCArtboard id="colors-dark" label="Colors · Dark" width={960} height={920}>
          <DSColors dark={true}/>
        </DCArtboard>

        <DCArtboard id="type" label="Typography" width={960} height={760}>
          <DSType />
        </DCArtboard>

        <DCArtboard id="spacing" label="Tap targets · radii · elevation" width={960} height={760}>
          <DSSpacing />
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Root />);
